import regex._main
from regex._main import *
__all__ = regex._main.__all__
